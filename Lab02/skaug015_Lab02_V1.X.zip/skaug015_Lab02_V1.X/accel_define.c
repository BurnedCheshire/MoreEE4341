/* ************************************************************************** */
/** accel_define.c

  @Description
    Delay function and define statements.
 */
/* ************************************************************************** */

#include "accel_define.h"

// this file is only necessary when you are creating your library

//void delay(int ms)
//{
//    int countUp =0;
//	while(ms > 0)
//    {
//        while(countUp < 799900) //799900
//        {
//            asm("NOP");
//            countUp++;
//        } 
//            ms--;
//    }
//}

/* *****************************************************************************
 End of File
 */
