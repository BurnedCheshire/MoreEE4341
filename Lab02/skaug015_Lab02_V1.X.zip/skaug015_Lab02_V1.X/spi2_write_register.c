/* ************************************************************************** */
/** spi2_write_register.c

  @Description
    Send data to SPI buffer.
 */
/* ************************************************************************** */

#include "accel_define.h"       // Some #define statements in this file might be used 
#include "io_setup.h"

void spi2_write_register(uint8_t address, uint8_t data)
{   
    uint16_t write_frame;
    uint16_t trash;
    
    write_frame = ((uint16_t)address << 8) | data;
            
    delay(1);
    
    ACCEL_CS = 1;
    // enable accelerometer chip select

    SPI2BUF = write_frame;
    // send "write_frame" to the SPI2 buffer                     
    
    while(SPI2STATbits.SPIBUSY){}
    // wait for the SPI2 buffer full bit       
    
    SPI2BUF = trash;
    // clear SPI2 buffer using the "trash" variable
    
    ACCEL_CS = 0;
    // disable accelerometer chip select
}


/* *****************************************************************************
 End of File
 */
